import {useState} from 'react'
import {v4 as uuidv4} from 'uuid' // Importing uuidv4 to generate unique IDs

import './index.css'

const App = () => {
  const [posts, setPosts] = useState([])
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')

  const handleTitleChange = event => {
    setTitle(event.target.value)
  }

  const handleContentChange = event => {
    setContent(event.target.value)
  }

  const handleSubmit = event => {
    event.preventDefault()
    const newPost = {id: uuidv4(), title, content} // Generating unique ID for each post
    setPosts([...posts, newPost])
    setTitle('')
    setContent('')
  }

  return (
    <div className="post-container">
      <div className="post-wrapper">
        <div className="post-card">
          <h1 className="post-heading">Create Post</h1>
          <form onSubmit={handleSubmit}>
            <div className="post-inputs">
              <input
                type="text"
                className="post-input"
                placeholder="Post Title"
                value={title}
                onChange={handleTitleChange}
              />
            </div>
            <br />
            <div className="post-inputs">
              <textarea
                className="post-input"
                placeholder="Describe your post"
                value={content}
                onChange={handleContentChange}
                rows="5"
              />
            </div>
            <br />
            <div className="post-button">
              <button type="submit" className="post-btn">
                Post Submit
              </button>
            </div>
          </form>
        </div>
        <div className="post-card">
          <h1 className="post-heading">Posts</h1>
          {posts.map(post => (
            <div key={post.id}>
              {' '}
              {/* Using unique ID as key */}
              <h2 className="post-tile">{post.title}</h2>
              <p className="post-paragraph">{post.content}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default App
