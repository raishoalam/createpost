import {Link} from 'react-router-dom'
import {AiOutlineTable} from 'react-icons/ai'

import './index.css'

const Header = () => (
  <nav className="nav-header">
    <div className="blog-container">
      <div>
        <AiOutlineTable className="header-icon" />
      </div>
      <h1 className="header-heading">Anonymous</h1>
    </div>
  </nav>
)

export default Header
