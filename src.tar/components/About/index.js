import {FaArrowRight, FaRocket} from 'react-icons/fa6'
import {Link} from 'react-router-dom'
import '../Contact'
import './index.css'

const About = () => (
  <div className="about-container">
    <p className="home-paragraph">
      <FaRocket className="home-icons" /> For Indian Users Only
    </p>
    <h1 className="home-heading">
      Start Posting Anonymously where no one will judge.
    </h1>
    <p className="home-paragraph">Welcome to Stranger discussion forum</p>
    <div>
      <Link className="nav-link" to="/contact">
        <button type="button" className="home-btn">
          Create Your Account <FaArrowRight className="icons" />
        </button>
      </Link>
    </div>
    <p className="login-btn">
      Already have account?
      <Link to="/">
        <span className="style">Login</span>
      </Link>
    </p>
  </div>
)

export default About
