import {useState} from 'react'
import {FaRocket, FaArrowRight} from 'react-icons/fa6'
import {BsCheckCircle} from 'react-icons/bs'

import {Link} from 'react-router-dom'
import './index.css'

const AccountFlow = () => {
  const [step, setStep] = useState(1)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [otp, setOtp] = useState('')

  const handleNameChange = e => {
    setName(e.target.value)
  }

  const handleEmailChange = e => {
    setEmail(e.target.value)
  }

  const handleOtpChange = e => {
    setOtp(e.target.value)
  }

  const handleSubmitNameEmail = e => {
    e.preventDefault()
    // Perform validation if needed
    setStep(step + 1)
  }

  const handleSubmitOTP = e => {
    e.preventDefault()
    // Perform OTP verification, for now, let's assume it's correct
    alert('OTP Verified successfully!')

    setStep(step + 1)
  }

  return (
    <div className="about-container">
      <div className="about-card">
        {step === 1 && (
          <form onSubmit={handleSubmitNameEmail}>
            <div className="about-Icon">
              <FaRocket className="about-icons" />
            </div>
            <h1 className="card-heading">Create Your Account</h1>
            <div className="input-container">
              <input
                type="text"
                className="input-section"
                placeholder="Enter Your Name"
                value={name}
                onChange={handleNameChange}
              />
            </div>
            <br />
            <div className="input-container">
              <input
                type="email"
                className="input-section"
                placeholder="Enter Email Id"
                value={email}
                onChange={handleEmailChange}
              />
            </div>
            <br />
            <div className="card-button">
              <button type="submit" className="card-btn">
                Continue <FaArrowRight className="card-icons" />
              </button>
            </div>
          </form>
        )}
        {step === 2 && (
          <form onSubmit={handleSubmitOTP}>
            <div>
              <div className="about-Icon">
                <FaRocket className="about-icons" />
              </div>
              <h1 className="card-heading">Create Your Account</h1>
              <p className="about-paragraph">
                Please Verify your email ID to continue.
                <br />
                We have sent an OTP to this emailId
              </p>
            </div>

            <div className="input-container">
              <input
                type="text"
                className="input-section"
                placeholder="Enter OTP"
                value={otp}
                onChange={handleOtpChange}
              />
            </div>
            <br />
            <div className="card-button">
              <button type="submit" className="card-btn">
                Continue <FaArrowRight className="card-icons" />
              </button>
            </div>
          </form>
        )}
        {step === 3 && (
          <div>
            <div className="success-icon">
              <BsCheckCircle className="success-icons" />
            </div>
            <h2 className="success-msg">Account Created Successfully</h2>
            <div className="msg-Button">
              <Link to="/post">
                <button type="button" className="msg-btn">
                  Create Your First Post <FaArrowRight />
                </button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default AccountFlow
